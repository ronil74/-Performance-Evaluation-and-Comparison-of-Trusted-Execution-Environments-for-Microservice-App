#Running Sysbench Script to repeat 5 times
run_sysbench() {
    local threads=$1
    # Running actual benchmark to be repeated for calculation of prime number till 20000
    output=$(sysbench cpu --cpu-max-prime=20000 --threads=$threads run)
    events_per_second=$(echo "$output" | grep "events per second:" | awk '{print $4}')
    echo "Threads: $threads"
    echo "$output"
    echo "Events Per Second: $events_per_second"

    if [ -z "$events_per_second" ]; then
        events_per_second="N/A"
#if output not found set N/A just to avoid error in next script
        echo "Events per second not found for $threads threads, setting to N/A just to avoid error in next script"
    fi
# File named needs to be changed for each VM
    echo "$threads,$iteration,$events_per_second" >> amd_sev_results.csv
}

echo "Threads,Iteration,Events Per Second" > amd_sev_results.csv

thread_counts=(1 2 4 8 16)
# Using for loop to repeat the benchmarking 5 times.
for iteration in {1..5}; do
    echo "Starting benchmark iteration $iteration"
    # Run benchmarks for each thread count
    for threads in "${thread_counts[@]}"; do
        echo "Running sysbench with $threads threads (iteration $iteration)..."
        run_sysbench $threads
    done
done

echo "completed. Results==amd_sev_results.csv."
