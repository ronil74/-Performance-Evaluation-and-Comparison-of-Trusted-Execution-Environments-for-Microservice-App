--Configuration and Execution Steps for CPU benchmarking

Step 1: Installing Sysbench Dependencies on all the 4 VMs
        sudo apt-get update
        sudo apt-get install sysbench

Step 2: Checking TEE status on all the 4 VMs
        dmesg | grep TDX
        dmesg | grep SEV

Step 3: Running benchmark
        sysbench cpu --threads=4 --cpu-max-prime=20000 run

Step 4: Creating a shell file to automate benchmarking
        nano test.sh

Step 5: Making shell file executable
        chmod +x test.sh

Step 6: Running the shell script which would benchmark and provide results in csv file.
        ./test.sh

Step 7: Repeating script and configuration on all 4 VMs

Step 8: Creating a python script to read all the 4 csv files created by script and generate a bar plot

Step 9: Running python script(need a virtual environment)
        python3 combine.py

Step 10: Generated bar plot can be downloaded onto local machine using scp