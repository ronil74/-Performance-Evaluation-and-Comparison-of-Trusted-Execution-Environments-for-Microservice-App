import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#importing all the csv files 
amd_sev = pd.read_csv('amd_sev_results.csv')
amd = pd.read_csv('amd_results.csv')
non_tdx = pd.read_csv('non_tdx_results.csv')
tdx = pd.read_csv('tdx_results.csv')

#Extracting data
amd_sev_stats = amd_sev.groupby('Threads')['Events Per Second'].agg(['mean', 'std']).reset_index()
amd_stats = amd.groupby('Threads')['Events Per Second'].agg(['mean', 'std']).reset_index()
non_tdx_stats = non_tdx.groupby('Threads')['Events Per Second'].agg(['mean', 'std']).reset_index()
tdx_stats = tdx.groupby('Threads')['Events Per Second'].agg(['mean', 'std']).reset_index()
#Create a bar plot
fig, c = plt.subplots(figsize=(4,5))
bar_width = 0.2
bar_positions1 = np.arange(len(amd_sev_stats['Threads'])) - bar_width * 1.5
bar_positions2 = np.arange(len(amd_stats['Threads'])) - bar_width * 0.5
bar_positions3 = np.arange(len(non_tdx_stats['Threads'])) + bar_width * 0.5
bar_positions4 = np.arange(len(tdx_stats['Threads'])) + bar_width * 1.5
#seting bar position with respective colours
c.bar(bar_positions1, amd_sev_stats['mean'], width=bar_width, yerr=amd_sev_stats['std'],
       label='AMD SEV', color='blue', capsize=5)
c.bar(bar_positions2, amd_stats['mean'], width=bar_width, yerr=amd_stats['std'],
       label='AMD', color='orange', capsize=5)
c.bar(bar_positions3, non_tdx_stats['mean'], width=bar_width, yerr=non_tdx_stats['std'],
       label='Non-TDX', color='lightgreen', capsize=5)
c.bar(bar_positions4, tdx_stats['mean'], width=bar_width, yerr=tdx_stats['std'],
       label='TDX', color='cyan', capsize=5)
c.set_xlabel('Threads')
c.set_ylabel('Events Per Second')
c.set_xticks(np.arange(len(amd_sev_stats['Threads'])))
c.set_xticklabels(amd_sev_stats['Threads'])
c.set_ylim(0, 2400)
c.legend(loc='upper right')
plt.tight_layout()
plt.savefig('benchmark_demo.png')
plt.show()
