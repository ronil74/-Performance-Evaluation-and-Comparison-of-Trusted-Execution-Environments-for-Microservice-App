SELECT * FROM ron WHERE age > 50;
SELECT COUNT(*) FROM ron;
SELECT * FROM ron ORDER BY name LIMIT 10;
UPDATE ron SET age = age + 1 WHERE id % 2 = 0;
DELETE FROM ron WHERE age < 20;
INSERT INTO ron (name, age) VALUES ('Ronil', 24);

