DELIMITER $$
CREATE PROCEDURE PopulateUsers1()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 2000 DO
        INSERT INTO ron (name, age) VALUES (CONCAT('ron', i), FLOOR(RAND() * 100));
        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;

CALL PopulateUsers1();