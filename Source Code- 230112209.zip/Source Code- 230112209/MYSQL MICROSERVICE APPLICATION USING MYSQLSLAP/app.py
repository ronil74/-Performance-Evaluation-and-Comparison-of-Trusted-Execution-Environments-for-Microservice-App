from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

db_config = {
    'user': 'testuser',
    'password': 'password',
    'host': '127.0.0.1',
    'database': 'testdb'
}

@app.route('/insert', methods=['POST'])
def insert():
    data = request.json
    name = data.get('name')
    age = data.get('age')

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (name, age) VALUES (%s, %s)", (name, age))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({"message": "Record inserted"}), 201

@app.route('/query', methods=['GET'])
def query():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    return jsonify(rows), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)


  