import re
import matplotlib.pyplot as plt
import numpy as np

#Loading csv file, extracting and parsing all the key parameters needed.
def parse_benchmark_file(file_path):
    concurrency_levels = []
    avg_execution_times = []
    min_execution_times = []
    max_execution_times = []
    with open(file_path, 'r') as file:
        content = file.read()
    pattern = r'Benchmark\s+Average number of seconds to run all queries: ([\d.]+) seconds\s+Minimum number of seconds to run all queries: ([\d.]+) seconds\s+Maximum number of seconds to run all queries: ([\d.]+) seconds\s+Number of clients running queries: (\d+)'
    matches = re.findall(pattern, content, re.DOTALL)
    for match in matches:
        avg_time = float(match[0])
        min_time = float(match[1])
        max_time = float(match[2])
        num_clients = int(match[3])
        
        concurrency_levels.append(num_clients)
        avg_execution_times.append(avg_time)
        min_execution_times.append(min_time)
        max_execution_times.append(max_time)

    return concurrency_levels, avg_execution_times, min_execution_times, max_execution_times

#File paths and key parameters
concurrency_levels_1, avg_times_1, min_times_1, max_times_1 = parse_benchmark_file('benchmark_results_tdx.txt')
concurrency_levels_2, avg_times_2, min_times_2, max_times_2 = parse_benchmark_file('benchmark_results.txt')
concurrency_levels_3, avg_times_3, min_times_3, max_times_3 = parse_benchmark_file('benchmark_results_with_sev.txt')
concurrency_levels_4, avg_times_4, min_times_4, max_times_4 = parse_benchmark_file('benchmark_results_without_sev.txt')

#Plotting the bar plot
plt.figure(figsize=(4,5))
bar_width = 0.2
bar_positions_1 = np.arange(len(concurrency_levels_1))
bar_positions_2 = bar_positions_1 + bar_width
bar_positions_3 = bar_positions_2 + bar_width
bar_positions_4 = bar_positions_3 + bar_width
errors_1 = [np.array(avg_times_1) - np.array(min_times_1), np.array(max_times_1) - np.array(avg_times_1)]
errors_2 = [np.array(avg_times_2) - np.array(min_times_2), np.array(max_times_2) - np.array(avg_times_2)]
errors_3 = [np.array(avg_times_3) - np.array(min_times_3), np.array(max_times_3) - np.array(avg_times_3)]
errors_4 = [np.array(avg_times_4) - np.array(min_times_4), np.array(max_times_4) - np.array(avg_times_4)]
plt.bar(bar_positions_1, avg_times_1, bar_width, yerr=errors_1, label='TDX', color='cyan', capsize=5)
plt.bar(bar_positions_2, avg_times_2, bar_width, yerr=errors_2, label='Non TDX', color='lightgreen', capsize=5)
plt.bar(bar_positions_3, avg_times_3, bar_width, yerr=errors_3, label='AMD SEV', color='blue', capsize=5)
plt.bar(bar_positions_4, avg_times_4, bar_width, yerr=errors_4, label='AMD', color='orange', capsize=5)
plt.xlabel('Number of Clients')
plt.ylabel('Average Execution Time (seconds)')
plt.xticks(bar_positions_1 + 1.5 * bar_width, concurrency_levels_1)
plt.legend()
plt.grid(True)
plt.savefig('mysql.png')
plt.show()

