SELECT * FROM users WHERE age > 50;
SELECT COUNT(*) FROM users;
SELECT * FROM users ORDER BY name LIMIT 10;
UPDATE users SET age = age + 1 WHERE id % 2 = 0;
DELETE FROM users WHERE age < 20;
INSERT INTO users (name, age) VALUES ('NewUser', 25);
