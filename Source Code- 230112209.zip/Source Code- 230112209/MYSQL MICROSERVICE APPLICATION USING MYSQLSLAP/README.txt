--Configuration and Execution Steps for MySQL Microservice Application.

Step 1: Installing Mysql server and mysqlslap(mysql-client) Dependencies on all the 4 VMs
        sudo apt-get update
        sudo apt-get install mysql-server
        sudo apt-get install mysql-client
               
Step 2: Checking TEE status on all the 4 VMs
        dmesg | grep TDX
        dmesg | grep SEV

Step 3: Creating alternative app.py to start the server an port
        nano app.py
        python3 app.py

Step 4: Create and Configure a MySQL Database
        mysql -u root -p

-----------------------
        CREATE DATABASE testdb1;
	CREATE USER 'testuser1'@'%' IDENTIFIED BY 'password';
	GRANT ALL PRIVILEGES ON testdb.* TO 'testuser1'@'%';
	FLUSH PRIVILEGES;
	EXIT;

Step 5: Create Table in the database
        mysql -u testuser -p

----------------------
        USE testdb;
	CREATE TABLE users (
    	id INT AUTO_INCREMENT PRIMARY KEY,
    	name VARCHAR(255) NOT NULL,
    	age INT NOT NULL
	);

Step 6: Auto populate data into table:
        USE testdb;

------------------------
        -- Insert 10000 sample records
	DELIMITER $$
	CREATE PROCEDURE PopulateUsers()
	BEGIN
    		DECLARE i INT DEFAULT 1;
    		WHILE i <= 10000 DO
        		INSERT INTO users (name, age) VALUES (CONCAT('User', i), FLOOR(RAND() * 100));
        		SET i = i + 1;
    			END WHILE;
		END$$
	DELIMITER ;

	CALL PopulateUsers();
        

Step 7: Creating queries to automate benchmarking which are stored in queries.sql 
        nano queries.sql

Step 8: Running benchmark
        mysqlslap --user=testuser --password=password --host=127.0.0.1 --concurrency=10,20,50,100 --iterations=10 --create-schema=testdb --query=queries.sql --verbose > results.txt

Step 9: Repeating benchmark and configuration on all 4 VMs

Step 11: Creating a python script to read all the 4 csv files created by script and generate a bar plot

Step 12: Running python script(need a virtual environment)
        python3 combine.py

Step 13: Generated bar plot can be downloaded onto local machine using scp