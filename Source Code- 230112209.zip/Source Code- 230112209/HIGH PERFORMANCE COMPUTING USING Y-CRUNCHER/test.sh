#Bencharking High perfromance computing application using y-cruncher
run_y_cruncher() {
    local threads=$1    
    # Run y-cruncher with skip-warnings and benchmark 500 million digits
    output=$(OMP_NUM_THREADS=$threads ./y-cruncher skip-warnings bench 500m)
    total_computation_time=$(echo "$output" | grep -oP '(?<=Total Computation Time:)[^()]*' | awk '{print $1}')
    echo "Threads: $threads"
    echo "$output"
    echo "Extracted Total Computation Time: $total_computation_time seconds"
    # If the benchmarks fails save data as N/A , incase the benchmark encounter any error
    if [ -z "$total_computation_time" ]; then
        total_computation_time="N/A"
        echo "Total Computation Time not found for $threads threads, setting to N/A"
    fi

    echo "$threads,$total_computation_time" >> ycruncher_performance_results.csv
}


echo "Threads,Total Computation Time (seconds)" > ycruncher_performance_results.csv

thread_counts=(1 2 4 8 16)
# Iterating through all the thread counts
for threads in "${thread_counts[@]}"; do
    echo "Running y-cruncher with $threads threads..."
    run_y_cruncher $threads
done

echo "All benchmarks completed. Results saved in ycruncher_performance_results_amd_sev.csv."
