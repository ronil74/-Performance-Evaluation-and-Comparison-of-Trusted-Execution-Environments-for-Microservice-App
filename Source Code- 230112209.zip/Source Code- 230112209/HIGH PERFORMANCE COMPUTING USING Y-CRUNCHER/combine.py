import pandas as pd
import matplotlib.pyplot as plt
import re
import numpy as np
#cleaning data obtained from the csv files
def clean_data(lines):
    cleaned_lines = []
    for line in lines:
        cleaned_line = re.sub(r'\x1B\[[0-?]*[ -/]*[@-~]', '', line)
        cleaned_line = cleaned_line.strip()
        cleaned_line = cleaned_line.split(',')
        cleaned_lines.append(cleaned_line)
    return cleaned_lines
# importing csv files obtained after benchmarking
def loadcsv(file_path):
    with open(file_path, 'r') as file:
        raw_data = file.readlines()
    cleaned_data = clean_data(raw_data)
    df = pd.DataFrame(cleaned_data[1:], columns=cleaned_data[0])
    df["Total Computation Time (seconds)"] = df["Total Computation Time (seconds)"].apply(lambda x: float(x.split('m')[-1]) if x is not None else None)
    return df
file_paths = ['amdsev.csv', 'amd.csv', 'tdx.csv', 'nontdx.csv']

amdsev_df = loadcsv('amdsev.csv')
amd_df = loadcsv('amd.csv')
tdx_df = loadcsv('tdx.csv')
nontdx_df = loadcsv('nontdx.csv')

#plotting bar plot
plt.figure(figsize=(4, 5))
bar_width = 0.2
x = np.array([1, 2, 4, 8, 16])
plt.bar(amdsev_df['Threads'].astype(int) - 1.5 * bar_width, amdsev_df['Total Computation Time (seconds)'].astype(float), width=bar_width, color='blue', align='center', label='AMD SEV')
plt.bar(amd_df['Threads'].astype(int) - 0.5 * bar_width, amd_df['Total Computation Time (seconds)'].astype(float), width=bar_width, color='orange', align='center', label='AMD')
plt.bar(tdx_df['Threads'].astype(int) + 0.5 * bar_width, tdx_df['Total Computation Time (seconds)'].astype(float), width=bar_width, color='cyan', align='center', label='TDX')
plt.bar(nontdx_df['Threads'].astype(int) + 1.5 * bar_width, nontdx_df['Total Computation Time (seconds)'].astype(float), width=bar_width, color='green', align='center', label='Non-TDX')
plt.xlim(0.5, 16.5)
plt.xticks(x, labels=['1', '2', '4', '8', '16'])
plt.ylim(50, 750)
plt.xlabel('Threads')
plt.ylabel('Total Computation Time (seconds)')
plt.legend()
plt.tight_layout()
plt.savefig('results.png')

