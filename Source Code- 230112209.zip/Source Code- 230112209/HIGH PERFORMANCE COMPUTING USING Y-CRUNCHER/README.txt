--Configuration and Execution Steps for High Performance Computing Application

Step 1: Installing Y-cruncher Dependencies on all the 4 VMs
        wget http://www.numberworld.org/y-cruncher/old_versions/y-cruncher v0.8.5.9542-static.tar.xz    #Downloading the application zip file
        tar -xf y-cruncher\ v0.8.5.9542-static.tar.xz
        mv  v0.8.5.9542-static.tar.xz  ycrunch      #Renaming file for easy access        
        
Step 2: Checking TEE status on all the 4 VMs
        dmesg | grep TDX
        dmesg | grep SEV

Step 3: Running benchmark 
        Chmod +x y-cruncher
        ./y-cruncher

Step 4: Running benchmark with all default settings
        ./y-cruncher bench all

Step 5: Creating a shell file to automate benchmarking
        nano test.sh

Step 6: Making shell file executable
        chmod +x test.sh

Step 7: Running the shell script which would benchmark and provide results in csv file.
        ./test.sh

Step 8: Repeating script and configuration on all 4 VMs

Step 9: Creating a python script to read all the 4 csv files created by script and generate a bar plot

Step 10: Running python script(need a virtual environment)
        python3 combine.py

Step 11: Generated bar plot can be downloaded onto local machine using scp