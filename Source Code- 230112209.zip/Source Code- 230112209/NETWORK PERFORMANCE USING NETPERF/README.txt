--Configuration and Execution Steps for Network Benchmarking

Step 1: Installing Netperf Dependencies on all the 4 VMs
        sudo apt-get update
        sudo apt-get install netperf
              
Step 2: Checking TEE status on all the 4 VMs
        dmesg | grep TDX
        dmesg | grep SEV

Step 3: Making the Netserver active on all the 4 VMs using port 20000
        netserver -p 20000

Step 4: To check the IP address of the running netserver
        sudo lsof -i :20000
        ip addr show
        
        -----------During execution - non tdx:10.0.0.5 , non sev:10.1.0.4 , amd sev, intel tdx:10.0.0.4


Step 5: Running Benchmarking - IP address needs to be changed according to the server used.
        netperf -H 10.0.0.4 -p 20000 -t TCP_STREAM -l 50
        netperf -H 10.0.0.4 -p 20000 -t UDP_STREAM -l 50
        netperf -H 10.0.0.4 -p 20000 -t TCP_RR -l 50
        netperf -H 10.0.0.4 -p 20000 -t UDP_RR -l 50


Step 6: Creating a two shell file to automate benchmarking of throughput and transmission rate 
        nano throughput.sh
        nano trans.sh

Step 7: Making shell file executable
        chmod +x throughput.sh
        chmod +x trans.sh

Step 8: Running the shell script which would benchmark 5 times and provide results in csv file.
        ./throughput.sh
        ./trans.sh

Step 9: Repeating script and configuration on all 4 VMs

Step 10: Creating 2 python script to read all the 4 csv files generated for throughput and tansmission rate separately created by shell scripts and generate bar plots.

Step 11: Running python script(need a virtual environment)
        python3 throughput.py
        python3 trans.py

Step 12: Generated bar plot can be downloaded onto local machine using scp