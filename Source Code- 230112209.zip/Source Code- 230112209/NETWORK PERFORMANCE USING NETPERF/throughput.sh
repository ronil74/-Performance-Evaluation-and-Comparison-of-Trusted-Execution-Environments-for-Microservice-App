#Server IP needs to be changed based on the net server ip address
SERVER_IP="10.0.0.4"
#Below files are configuration files to store output and run it for 5 times
OUTPUT_FILE="netperf_throughput_results.csv"
RUNS=5 
#Below file can be used to store file in the given format
echo "Test Type,Run,Throughput" > $OUTPUT_FILE

#Use below tests as defined for benchmarking
declare -A TESTS=(
    ["TCP_STREAM"]="netperf -H $SERVER_IP -p 20000 -t TCP_STREAM -l 10"
    ["UDP_STREAM"]="netperf -H $SERVER_IP -p 20000 -t UDP_STREAM -l 10"
)
#extracting throughput from the benchmarking output
extract_throughput() {
    local output="$1"
    echo "$output" | awk '
    /Throughput/ {
        getline;
        while (getline) {
            if ($NF ~ /^[0-9.]+$/) {
                print $NF;
                exit;
            }
        }
    }'
}

#Saving values in the csv file
for TEST_TYPE in "${!TESTS[@]}"; do
    for ((i = 1; i <= RUNS; i++)); do
        echo "Running $TEST_TYPE benchmark (Run $i)..."
        OUTPUT=$(eval "${TESTS[$TEST_TYPE]}")     
        THROUGHPUT=$(extract_throughput "$OUTPUT")
        
        if [ -n "$THROUGHPUT" ]; then
            echo "$TEST_TYPE,$i,$THROUGHPUT" >> $OUTPUT_FILE
            echo "Completed $TEST_TYPE (Run $i) with throughput: $THROUGHPUT"
        else
            echo "Failed to extract throughput for $TEST_TYPE (Run $i)"
        fi
    done
done

echo "Results saved to $OUTPUT_FILE"
