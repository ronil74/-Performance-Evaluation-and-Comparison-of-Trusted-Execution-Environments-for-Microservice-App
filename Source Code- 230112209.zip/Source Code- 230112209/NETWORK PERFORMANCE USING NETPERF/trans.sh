#Server IP needs to be changed based on the net server ip address
SERVER_IP="10.0.0.4"
#Below files are configuration files to store output and run it for 5 times
OUTPUT_FILE="netperf_transmission_rate_results.csv"
RUNS=5
#Below file can be used to store file in the given format
echo "Test Type,Run,Transmission Rate (trans/sec)" > $OUTPUT_FILE

#Use below tests as defined for benchmarking
declare -A TESTS=(
    ["TCP_RR"]="netperf -H $SERVER_IP -p 20000 -t TCP_RR -l 10"
    ["UDP_RR"]="netperf -H $SERVER_IP -p 20000 -t UDP_RR -l 10"
)

#extracting transmission rate from the benchmarking output
extract_transmission_rate() {
    local output="$1"
    echo "$output" | awk '
    /Rate/ { 

        getline; 
        while (getline) {
            if ($NF ~ /^[0-9.]+$/) {
                print $NF;
                exit;
            }
        }
    }'
}

#Saving values in the csv file
for TEST_TYPE in "${!TESTS[@]}"; do
    for ((i = 1; i <= RUNS; i++)); do
    	echo "Running $TEST_TYPE benchmark (Run $i)..."
    	OUTPUT=$(eval "${TESTS[$TEST_TYPE]}")
    	TRANSMISSION_RATE=$(extract_transmission_rate "$OUTPUT")
   	 if [ -n "$TRANSMISSION_RATE" ]; then
        	echo "$TEST_TYPE,$TRANSMISSION_RATE" >> $OUTPUT_FILE
        	echo "Completed $TEST_TYPE (Run $i) with transmission rate: $TRANSMISSION_RATE"
    	else
        	echo "Failed to extract transmission rate for $TEST_TYPE (Run $i)"
    	fi
	done
done

echo "Results saved to $OUTPUT_FILE"
