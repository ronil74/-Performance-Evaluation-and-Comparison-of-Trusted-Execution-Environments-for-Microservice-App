import csv
import numpy as np
import matplotlib.pyplot as plt

#Reading data from the imported dataframe
def load_transmission_rate_results(filenames):
    results = {}

    for filename, label in filenames.items():
        results[label] = {}
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            next(reader)  
            for row in reader:
                if len(row) == 3:  
                    test_type, run, transmission_rate = row
                    if test_type not in results[label]:
                        results[label][test_type] = []
                    results[label][test_type].append(float(transmission_rate))
                else:
                    print(f"Skipping malformed row in {filename}: {row}")

    return results

# Error bar calculations
def calculate_stats(results):
    stats = {}

    for label, test_results in results.items():
        stats[label] = {}
        for test_type, values in test_results.items():
            mean_val = np.mean(values)
            std_dev = np.std(values)
            stats[label][test_type] = (mean_val, std_dev)

    return stats

#Plotting graph using the same configuration across all benchmarks
def plot_transmission_rate(stats):
    test_types = list(stats[next(iter(stats))].keys())
    machines = list(stats.keys())
    x = np.arange(len(test_types))
    width = 0.2
    colors = {
        'amd': 'orange',
        'amd sev': 'blue',
        'tdx': 'cyan',
        'non tdx': 'lightgreen'
    }
    fig, n = plt.subplots(figsize=(4,5))

    for i, machine in enumerate(machines):
        means = [stats[machine][test_type][0] for test_type in test_types]
        std_devs = [stats[machine][test_type][1] for test_type in test_types]
        n.bar(x + i * width, means, width, yerr=std_devs, label=machine,color=colors[machine] ,capsize=6)

    n.set_xlabel('Test Type')
    n.set_ylabel('Transmission Rate (trans/sec)')
    n.set_xticks(x + width / 2 * (len(machines) - 1))
    n.set_xticklabels(test_types)
    n.set_ylim(0,70000) 
    n.legend(loc='upper left')
    plt.tight_layout()
    plt.savefig('transmission_rate.png')
    plt.show()

def main():
    filenames = {
        'netperf_transmission_rate_results_amd.csv': 'amd',
        'netperf_transmission_rate_results_amd_sev.csv': 'amd sev',
        'netperf_transmission_rate_results_tdx.csv': 'tdx',
        'netperf_transmission_rate_results_non_tdx.csv': 'non tdx'
    }

    results = load_transmission_rate_results(filenames)
    stats = calculate_stats(results)
    plot_transmission_rate(stats)

if __name__ == "__main__":
    main()
